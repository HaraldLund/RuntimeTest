﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows;
using System.Windows.Input;
using Esri.ArcGISRuntime.Geometry;
using Esri.ArcGISRuntime.Mapping;
using Esri.ArcGISRuntime.UI;
using MapRefresh.View.ViewModel;

namespace MapRefresh
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow
    {
        #region Private members
        private ICommand _clearRequestsCommand;
        private string _navigationId = Guid.NewGuid().ToString();
        private readonly ConcurrentQueue<string> _temporaryRequestList = new ConcurrentQueue<string>();
        private readonly ConcurrentDictionary<string, TileRequestDetails> _requestDictionary =
            new ConcurrentDictionary<string, TileRequestDetails>();
        private Envelope _initialExtent;
        private ICommand _setViewCommand;
        #endregion

        public MainWindow()
        {
            Items = new ObservableCollection<string>();
            DataContext = this;
            Esri.ArcGISRuntime.Http.ArcGISHttpClientHandler.HttpRequestBegin += ArcGISHttpClientHandler_HttpRequestBegin;
            InitializeComponent();
            MyMapView.DrawStatusChanged += MyMapView_DrawStatusChanged;
        }

        private void MyMapView_DrawStatusChanged(object sender, DrawStatusChangedEventArgs e)
        {
            UpdateStatus(e.Status == DrawStatus.Completed);
        }

        public void UpdateStatus(bool isComplete)
        {
            Dispatcher.Invoke(delegate ()
            {
                // Show the activity indicator if the map is drawing
                if (isComplete == false)
                {
                    ActivityIndicator.IsEnabled = true;
                    ActivityIndicator.Visibility = Visibility.Visible;
                }
                else
                {
                    ActivityIndicator.IsEnabled = false;
                    ActivityIndicator.Visibility = Visibility.Collapsed;
                    UpdateTileCount();
                }
            });
        }

        private void UpdateTileCount()
        {
            var navId = _navigationId;
            _navigationId = Guid.NewGuid().ToString();
            var tileRequestDetails = _requestDictionary.ToList()
                .Select(m => m.Value)
                .Where(m => m.NavigationId == navId)
                .OrderBy(m => m.Level)
                .ToList();
            _requestDictionary.Clear();
            Items.Clear();
            if (tileRequestDetails.Count == 0)
            {
                return;
            }

            StringBuilder builder = new StringBuilder();
            builder.AppendLine(
                $"{tileRequestDetails.Sum(m => m.Tiles)} tiles between LoD {tileRequestDetails.Min(m => m.Level)} -> {tileRequestDetails.Max(m => m.Level)}");
            foreach (var lod in tileRequestDetails.Select(m => m.Level).Distinct())
            {
                var forLevel = tileRequestDetails.Where(m => m.Level == lod)
                    .ToList();
                builder.AppendLine($"\tLevel {lod} - Total tiles {forLevel.Sum(m => m.Tiles)}");
                foreach (var item in forLevel.OrderBy(m => m.MapService))
                {
                    builder.AppendLine($"\t\t{item.Tiles} tiles - ({item.MapService})");
                }
            }

            Summary = builder.ToString();
            int i = 1;
            while(!_temporaryRequestList.IsEmpty)
            {
                if (_temporaryRequestList.TryDequeue(out var item))
                {
                    Items.Add($"#{i++} {item}");
                }
            }
        }

        private void ArcGISHttpClientHandler_HttpRequestBegin(object sender, System.Net.Http.HttpRequestMessage e)
        {
            if (!e.RequestUri.PathAndQuery.Contains("/MapServer/tile/"))
            {
                return;
            }

            var requestDetails = TileRequestDetails.Parse(e.RequestUri, _navigationId);
            UpdateCount(requestDetails);
            _temporaryRequestList.Enqueue($"{requestDetails.MapService} LoD {requestDetails.Level}");
        }


        private void UpdateCount(TileRequestDetails requestDetails)
        {
            string key = $"{requestDetails.Level}_{requestDetails.NavigationId}_{requestDetails.MapService}";
            if (_requestDictionary.TryGetValue(key, out var info))
            {
                info.Tiles = info.Tiles + 1;
            }
            else
            {
                requestDetails.Tiles = 1;
                _requestDictionary.TryAdd(key, requestDetails);
            }
        }

        public static readonly DependencyProperty IsZoomOverrideProperty = DependencyProperty.Register("IsZoomOverride", typeof(bool), typeof(MainWindow), new FrameworkPropertyMetadata(true));
        
        
        public static readonly DependencyProperty SummaryProperty = DependencyProperty.Register("Summary", typeof(string), typeof(MainWindow), new FrameworkPropertyMetadata(null));
        public static readonly DependencyProperty UseAnimationProperty = DependencyProperty.Register("UseAnimation", typeof(bool), typeof(MainWindow), new FrameworkPropertyMetadata(true));
        
        public bool UseAnimation
        {
            get
            {
                return (bool)GetValue(UseAnimationProperty);
            }
            set
            {
                SetValue(UseAnimationProperty, value);
            }
        }
        public bool IsZoomOverride
        {
            get
            {
                return (bool)GetValue(IsZoomOverrideProperty);
            }
            set
            {
                SetValue(IsZoomOverrideProperty, value);
            }
        }
        public string Summary
        {
            get
            {
                return (string)GetValue(SummaryProperty);
            }
            set
            {
                SetValue(SummaryProperty, value);
            }
        }
        public ObservableCollection<string> Items { get; }

        public ICommand ClearRequestsCommand => _clearRequestsCommand ??
                                                (_clearRequestsCommand =
                                                    new RelayCommand(param => OnClearRequestsCommand()));

        private void OnClearRequestsCommand()
        {
            Items.Clear();
            Summary = null;
        }

        public ICommand SetViewCommand => _setViewCommand ??
                                                (_setViewCommand =
                                                    new RelayCommand(param => OnSetViewCommand()));

        private async void OnSetViewCommand()
        {
            
            var center = GetRandomPoint();
            var scale = 625;
            if ((MyMapView.MapScale < 200000))
            {
                scale = 1000000;
            }
            if (UseAnimation)
            {
                await MyMapView.SetViewpointAsync(new Viewpoint(center, scale));
            }
            else
            {
                await MyMapView.SetViewpointAsync(new Viewpoint(center, scale), TimeSpan.Zero);
            }
        }

        private MapPoint GetRandomPoint()
        {
            
            if(_initialExtent == null)
            {
                _initialExtent = new Envelope(-247299.989220551, 6492055.69864222, 432816.894880079, 6992299.56471097, new SpatialReference(25833));
            }
            var x = new Random().Next((int)_initialExtent.XMin, (int)_initialExtent.XMax);
            var y = new Random().Next((int)_initialExtent.YMin, (int)_initialExtent.YMax);
            var center = new MapPoint(x, y, _initialExtent.SpatialReference);
            return center;
        }

    }
}
